package dev.wakandaacademy.produdoro.tarefa.domain;

public enum StatusTarefa {
	A_FAZER,CONCLUIDA
}
