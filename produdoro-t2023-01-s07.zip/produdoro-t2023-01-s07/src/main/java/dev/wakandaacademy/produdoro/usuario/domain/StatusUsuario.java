package dev.wakandaacademy.produdoro.usuario.domain;

public enum StatusUsuario {
	FOCO, PAUSA_CURTA, PAUSA_LONGA;
}
